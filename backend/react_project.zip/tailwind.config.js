module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        'beige-100': '#f5f5dc',
      },
    },
  },
  plugins: [],
};